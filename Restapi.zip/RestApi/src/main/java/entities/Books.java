package entities;

public class Books {
	private int bookid;
	@Override
	public String toString() {
		return "Books [bookid=" + bookid + ", title=" + title + ", Author=" + Author + "]";
	}
	public Books() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Books(int bookid, String title, String author) {
		super();
		this.bookid = bookid;
		this.title = title;
		this.Author = author;
	}
	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return Author;
	}
	public void setAuthor(String author) {
		Author = author;
	}
	private String title;
	private String Author;

}
