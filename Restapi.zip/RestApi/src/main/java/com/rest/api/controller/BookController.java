package com.rest.api.controller;
import entities.Books;
import services.BookServices;
import services.BookServices;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

//@Controller
@RestController
public class BookController {
	
	private BookServices bookService;
	
	//@RequestMapping(value="/books" ,method=RequestMethod.GET)
	//@ResponseBody
	@GetMapping("/books")
	public List<Books> getbooks() {
		
		
		return this.bookService.getAllBooks();
	}
	
	 @GetMapping("/books/{id}")
	    public Books getBook(@PathVariable("id") int id) {
	        return bookService.getBookById(id);
	 }
	 
	 @PostMapping("/books")
	 public @ResponseBody Books addBook(@RequestBody Books book1) {
		 Books b=this.bookService.addbook(book1);
		 System.out.println(book1);
		 return b;
	 }
}
