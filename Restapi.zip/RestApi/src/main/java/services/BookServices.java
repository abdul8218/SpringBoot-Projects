package services;
import entities.Books;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
@Component
public class BookServices {
	
	private static List<Books> list1=new ArrayList<>();
	
	static {
		
		list1.add(new Books(2345,"Programming using Python","Albert Einstien"));
		list1.add(new Books(6789,"Programming using Java SCript","Essac Newton"));
		list1.add(new Books(1234,"Programming using Ruby","Faraday"));
		
	}
	public List<Books> getAllBooks(){
		
		
		return list1;
	}
	
	public Books getBookById(int id) {
		
		Books bookNew;
		bookNew=list1.stream().filter(t->t.getBookid()==id).findFirst().get();
		return bookNew;
		
	}
	public Books addbook(Books b) {
		
		list1.add(b);
		return b;
	}

}
